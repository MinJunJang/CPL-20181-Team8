package com.example.sec.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class ExplainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explain);
    }

    public void onBackButtonCliked(View v){
        Toast.makeText(this,"onBackButtonCliked",Toast.LENGTH_SHORT).show();
        finish();
    }

}
